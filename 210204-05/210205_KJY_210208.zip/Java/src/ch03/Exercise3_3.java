package ch03;

public class Exercise3_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 10;
		System.out.println(num==0? "0" : num > 0 ? "���" : "����");
	}

}
