package ch03;

public class Exercise3_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 333;
		System.out.println(num - num%10 +1);
	}

}
