package ch03;

public class Exercise3_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch = 'z';
		boolean b = (ch>=48 && ch<=122);
		System.out.println(b);
	}

}
