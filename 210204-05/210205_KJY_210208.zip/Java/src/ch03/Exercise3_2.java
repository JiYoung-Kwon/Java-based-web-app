package ch03;

public class Exercise3_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numOfApples = 123;
		int sizeOfBucket = 10;
		int numOfBucket = (numOfApples%sizeOfBucket)==0 ? numOfApples/sizeOfBucket : numOfApples/sizeOfBucket +1;
		
		System.out.println("�ʿ��� �ٱ����� �� :"+numOfBucket);
	}

}
