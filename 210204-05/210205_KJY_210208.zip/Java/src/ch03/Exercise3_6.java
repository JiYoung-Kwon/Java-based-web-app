package ch03;

public class Exercise3_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 24;
		System.out.println(10 - num%10 );
	}

}
