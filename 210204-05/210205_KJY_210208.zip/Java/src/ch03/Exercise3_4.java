package ch03;

public class Exercise3_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 456;
		System.out.println(num/100*100);
	}

}
