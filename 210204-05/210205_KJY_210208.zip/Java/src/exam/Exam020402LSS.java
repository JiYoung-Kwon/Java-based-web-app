/*
 ������ : 20210204
 ���� : p98 ǥ3-6 ����
 ������ : ������
*/
package exam;

public class Exam020402LSS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(3/0.0);
		System.out.println(3%0.0); 
		System.out.println();
		System.out.println(3/Double.POSITIVE_INFINITY);
		System.out.println(3%Double.POSITIVE_INFINITY);
		System.out.println();
		System.out.println(0.0/0.0);
		System.out.println(0.0%0.0);
		System.out.println();
		System.out.println(Double.POSITIVE_INFINITY/3);
		System.out.println(Double.POSITIVE_INFINITY%3);
		System.out.println();
		System.out.println(Double.POSITIVE_INFINITY/Double.POSITIVE_INFINITY);
		System.out.println(Double.POSITIVE_INFINITY%Double.POSITIVE_INFINITY);
	}

}
