package ch04;

public class Exercise4_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cnt = 1;
		int sum = 0;

		while (true) {
			if (cnt % 2 == 0)
				sum -= cnt;
			else
				sum += cnt;

			if (sum >= 100) {
				System.out.printf("%d", cnt);
				break;
			}

			cnt++;
		}
	}

}
